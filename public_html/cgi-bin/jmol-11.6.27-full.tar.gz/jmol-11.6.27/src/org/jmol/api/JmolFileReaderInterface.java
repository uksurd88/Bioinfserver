package org.jmol.api;

import java.io.BufferedReader;

public interface JmolFileReaderInterface {
  BufferedReader getBufferedReader(int i);  
}