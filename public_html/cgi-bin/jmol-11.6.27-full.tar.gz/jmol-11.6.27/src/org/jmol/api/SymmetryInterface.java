package org.jmol.api;

import java.util.BitSet;
import java.util.Hashtable;

import javax.vecmath.Matrix4f;
import javax.vecmath.Point3f;
import javax.vecmath.Vector3f;

import org.jmol.modelset.Atom;

public interface SymmetryInterface {

  public abstract SymmetryInterface setPointGroup(
                                     SymmetryInterface pointGroupPrevious,
                                     Atom[] atomset, BitSet bsAtoms,
                                     boolean haveVibration,
                                     float distanceTolerance,
                                     float linearTolerance);

  public abstract String getPointGroupName();

  public abstract Object getPointGroupInfo(int modelIndex, boolean asDraw,
                                           boolean asInfo, String type,
                                           int index, float scale);

  public abstract void setSpaceGroup(boolean doNormalize);

  public abstract boolean addSpaceGroupOperation(String xyz);

  public abstract void setLattice(int latt);

  public abstract String getSpaceGroupName();

  public abstract Object getSpaceGroup();

  public abstract void setSpaceGroup(SymmetryInterface symmetry);

  public abstract boolean createSpaceGroup(int desiredSpaceGroupIndex,
                                           String name,
                                           float[] notionalUnitCell,
                                           boolean doNormalize);

  public abstract boolean haveSpaceGroup();

  public abstract int determineSpaceGroupIndex(String name);

  public abstract String getSpaceGroupInfo(String name, float[] unitCell);

  public abstract Object getLatticeDesignation();

  public abstract void setFinalOperations(Point3f[] atoms, int iAtomFirst,
                                          int noSymmetryCount,
                                          boolean doNormalize);

  public abstract int getSpaceGroupOperationCount();

  public abstract Matrix4f getSpaceGroupOperation(int i);

  public abstract String getSpaceGroupXyz(int i, boolean doNormalize);

  public abstract void newSpaceGroupPoint(int i, Point3f atom1, Point3f atom2,
                                          int transX, int transY, int transZ);

  public abstract Object rotateEllipsoid(int i, Point3f ptTemp,
                                         Vector3f[] axes, Point3f ptTemp1,
                                         Point3f ptTemp2);

  public abstract void setUnitCell(float[] notionalUnitCell);

  public abstract void toCartesian(Point3f pt);

  public abstract Object[] getEllipsoid(float[] parBorU);

  public abstract Point3f ijkToPoint3f(int nnn);

  public abstract void toFractional(Point3f pt);

  public abstract Point3f[] getUnitCellVertices();

  public abstract Point3f getCartesianOffset();

  public abstract float[] getNotionalUnitCell();

  public abstract void toUnitCell(Point3f pt, Point3f offset);

  public abstract void setUnitCellOffset(Point3f pt);

  public abstract void setOffset(int nnn);

  public abstract Point3f getFractionalOffset();

  public abstract float getUnitCellInfo(int infoType);

  public abstract int getModelIndex();

  public abstract void setModelIndex(int i);

  public abstract boolean getCoordinatesAreFractional();

  public abstract int[] getCellRange();

  public abstract String getSymmetryInfoString();

  public abstract String[] getSymmetryOperations();

  public abstract boolean haveUnitCell();

  public abstract String getUnitCellInfo();

  public abstract boolean isPeriodic();

  public abstract void setSymmetryInfo(int modelIndex, Hashtable modelAuxiliaryInfo);

}
